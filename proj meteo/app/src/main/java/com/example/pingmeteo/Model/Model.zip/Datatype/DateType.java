package com.example.ping_meteo.Model.Datatype;

import java.util.Date;

public class DateType {
    private Date date;

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
