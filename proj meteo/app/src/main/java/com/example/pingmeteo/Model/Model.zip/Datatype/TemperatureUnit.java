package com.example.ping_meteo.Model.Datatype;

public enum TemperatureUnit {
    CELSUS,
    FARHENHEIT,
    KELVIN
}
