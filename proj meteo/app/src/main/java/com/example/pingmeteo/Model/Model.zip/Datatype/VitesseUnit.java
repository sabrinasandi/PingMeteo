package com.example.ping_meteo.Model.Datatype;

public enum VitesseUnit {
    ms,
    kmh,
    mph,
    noeud
}
