package com.example.ping_meteo.Model.Datatype;

public class VitesseType {
    private int valeur;
    private VitesseUnit unite;

    public int getValeur() {
        return valeur;
    }

    public void setValeur(int valeur) {
        this.valeur = valeur;
    }

    public VitesseUnit getUnite() {
        return unite;
    }

    public void setUnite(VitesseUnit unite) {
        this.unite = unite;
    }
}
