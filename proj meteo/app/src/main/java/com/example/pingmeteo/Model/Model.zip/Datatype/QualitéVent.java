package com.example.ping_meteo.Model.Datatype;

public enum QualitéVent {
    CALME,
    VENTEUX,
    TEMPETE
}
