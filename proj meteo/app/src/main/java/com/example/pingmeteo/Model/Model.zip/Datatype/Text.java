package com.example.ping_meteo.Model.Datatype;

public class Text {
    private String valeur;

    public Text(String s){
        valeur = s;
    }

    public String getValeur() {
        return valeur;
    }

    public void setValeur(String valeur) {
        this.valeur = valeur;
    }
}
