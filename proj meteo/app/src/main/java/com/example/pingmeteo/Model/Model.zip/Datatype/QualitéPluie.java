package com.example.ping_meteo.Model.Datatype;

public enum QualitéPluie {
    CALME,
    PLUVIEUX,
    PLUIE_DILUVIENNE,
    NEIGE

}
