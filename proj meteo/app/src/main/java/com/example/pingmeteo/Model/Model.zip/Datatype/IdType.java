package com.example.ping_meteo.Model.Datatype;

public class IdType {
    private int valeur;

    public IdType(int val){
        this.valeur = val;
    }

    public int getValeur() {
        return valeur;
    }

    public void setValeur(int valeur) {
        this.valeur = valeur;
    }
}
